clear; clc;

biomart = readcell('biomart.xlsx');
biomart(1,:) = [];

[GOs] =unique(biomart(:,2));
[IDs] =unique(biomart(:,1));


IDs= string(IDs(:,:));
GOs= string(GOs(:,:));
mid_place = string(zeros(length(IDs),length(GOs)));


for i = 1:length(IDs)
    for j = 1:length(GOs)
        mid_place(i,j)=strcat(IDs(i),",",GOs(j));
    end
end














