clear; clc;

pc_data = readcell('protein_consensus.xlsx');
biomart = readcell('biomart.xlsx');
load('innie.mat');

pc_data(1,:) = [];
str_pc = string(pc_data(:,1));

biomart(1,:) = [];
bm_str=string(biomart);

names = cellstr(pc_data(:,1));
pc_data(:,1) = [];

[GOs] =unique(biomart(:,2));
[IDs] =unique(biomart(:,1));
IDs= string(IDs(:,:));
GOs= string(GOs(:,:));



bm_IDGOs=string(zeros(length(biomart),1));



for i = 1:length(biomart)
    bm_IDGOs(i,1)=strcat(bm_str(i,1),",",bm_str(i,2));
end



[IDS_GOs_bool,~] = ismember(mid_place,bm_IDGOs);





[bo,~] = ismember(str_pc,IDs);

id_tis = (cell2mat(pc_data)).*bo;
IDs_TIS=[names num2cell(id_tis)];

lol=5;

for i = flip(1:5786)
    if mean(cell2mat(IDs_TIS(i,2:14))) == 0
        IDs_TIS(i,:) = [];
    end
end

[~, idx] = sort(string(IDs_TIS(:,1)));
IDs_TIS = IDs_TIS(idx,:);

load('IDS_GOs_bool.mat')

Plz = IDS_GOs_bool'*(cell2mat(IDs_TIS(:,2:14)));
PLZ = [Plz zeros(9145,1)];
%LOOOOOOKK
for i =1:9145
    PLZ(i,14) = var(PLZ(i,1:13));
end

[~, var_idx] = sort(PLZ(:,14),'descend');
PLZ = [PLZ GOs(1:9145,:)];
PLZ = PLZ(var_idx,:);
PLZ = PLZ (1:50,:);
Vnam = {'adrenal gland' 'colon' 'esophagus' 'kidney' 'liver' 'lung' 'ovary' 'pancreas' 'prostate' 'testis' 'spleen' 'stomach' 'heart' 'Var' 'GO'};



figure(1)
h=heatmap(Vnam(1:13),PLZ(:,15),str2double(PLZ(:,1:13)));







